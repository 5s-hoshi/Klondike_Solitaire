#pragma once

struct data_pair_s {
	unsigned long x1;
	unsigned long x2;
	unsigned long a1;
	unsigned long a2;
	struct data_pair_s* next;
};
typedef struct data_pair_s data_pair_t;

class RandomSampler {
public:
						RandomSampler(unsigned long x1, unsigned long x2, unsigned long x3, unsigned long x4, unsigned long x5);
						RandomSampler();
						~RandomSampler();
	void				m90setseeds(unsigned long x1, unsigned long x2 , unsigned long x3, unsigned long x4, unsigned long x5);
	void				m90getseeds(unsigned long* x1, unsigned long* x2, unsigned long* x3, unsigned long* x4, unsigned long* x5);
	char				m90randombit();
	unsigned long		m90random31();
	double				m90randomu();
	/*��t�������֐�*/
	void				SeedQ();
	unsigned long		uniform(int num);

	unsigned long long used_num;

private:
	unsigned long omega[5];
};

class DRWS : public RandomSampler
{
public:
						DRWS(unsigned long x1, unsigned long x2, unsigned long x3, unsigned long x4, unsigned long x5);
						DRWS();
						~DRWS();
	//void				init_drws();				//�R���X�g���N�^�Ɉړ�
	//void				end_drws();					//�f�X�g���N�^�Ɉړ�
	long				get_locmax();
	void				set_first_location();
	unsigned long		drws31();
	double				drwsu();

private:
	long location;
	long locmax;
	long locmaxmax = -1;
	data_pair_t random_list;
	data_pair_t* current_ptr;

	void set_locmaxmax(long n);
};